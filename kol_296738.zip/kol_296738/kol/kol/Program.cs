﻿using System.Linq;
using System.Xml.Linq;
using System.Globalization;
using System;
using System.Collections.Generic;
using System.IO;
// using System.Data.SQLite;

/*
1. Zdefiniuj strukturę-rekord 'Słowo' zawierającą łańcuch (tekst
słowa), dwa pola typu int (długość słowa i liczba samogłosek) i pole
typu double (procent samogłosek). Z kolekcji 'słowa' (poniżej) wybierz
za pomocą zapytania LINQ łańcuchy, które mają długość 6 i umieść
informacje o nich w kolekcji List<Słowo>. Zrealizuj to za pomocą
jednego zapytania LINQ.
2. Korzystając z LINQ to XML (XDocument) umieść słowa z listy
List<Słowo> w pliku XML o korzeniu 'słowa' i elementach 'słowo'.
Obie liczby umieść atrybutach elementu 'słowo', natomiast tekst
powinien być jego zawartością. Zadbaj, aby liczba double z ostatniej
kolumny została zapisana z formatowaniem Invariant (kropka zamiast
przecinka).
3. Do bazy danych SQLite zapisz cztery kolumny danych odpowiadające
elementom z oryginalnej kolekcji 'słowa': tekst słowa, długość wyrazu,
liczbę samogłosek oraz procent samogłosek wśród liter. Użyj EF.
string[] słowa =
{
"czereśnia", "jabłko", "borówka", "wiśnia", "jagoda", "gruszka",
"śliwka", "malina"
};
*/

public struct Słowo
{
	public const string SAMOGŁOSKI = "aąeęiyouó";
	public string tekst_słowa { get; }
	public int długość_słowa { get; }
	public int liczba_samogłosek { get; }
	public double procent_samogłosek { get; }
	public Słowo(string tekst_słowa)
	{
		this.tekst_słowa = tekst_słowa;
		this.długość_słowa = tekst_słowa.Length;
		this.liczba_samogłosek = 0;

		foreach (char c in this.tekst_słowa.ToLower())
		{
			if (SAMOGŁOSKI.Contains(c))
			{
				this.liczba_samogłosek += 1;
			}
		}

		if (this.długość_słowa != 0)
		{
			this.procent_samogłosek = 100;
			this.procent_samogłosek *= Convert.ToDouble(this.liczba_samogłosek);
			this.procent_samogłosek /= Convert.ToDouble(this.długość_słowa);
		}
		else
		{
			this.procent_samogłosek = Double.NaN;
		}
	}
}


namespace Application
{
	class Program
	{
		static void Main(string[] args)
		{
			string[] słowa =
			{
				"czereśnia", "jabłko", "borówka", "wiśnia", "jagoda", "gruszka",
				"śliwka", "malina"
			};

			List<Słowo> słowa2 = (from słowo in słowa
								  where słowo.Length == 6
								  select new Słowo(słowo)).ToList();

			XDocument xml = new XDocument(
				new XDeclaration("1.0", "utf-8", "no"),
				new XElement("słowa",
					from słowo in słowa2
					select new XElement("słowo", słowo.tekst_słowa,
						new XAttribute("długość_słowa", słowo.długość_słowa),
						new XAttribute("liczba_samogłosek", słowo.liczba_samogłosek),
						new XAttribute("procent_samogłosek", słowo.procent_samogłosek.ToString("G", CultureInfo.InvariantCulture))
					)
				)
			);

			Console.WriteLine(xml.ToString());
			File.WriteAllText("słowa.xml", xml.ToString());



		//	using (var conn = new SQLiteConnection(@"słowa.sqlite"))
		//	{
		//	}
		}
	}
}